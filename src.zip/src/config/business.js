const business = {

  name: "Abe Mac Music",

  businessType: "Musician",

  tagline: "Live Music • Original Sound",

  about: "Abe Mac Music creates memorable music and unforgettable performances for fans everywhere.",

  phone: "9152677184",

  email: "stevemartin677@gmail.com",

  address: "",

  instagram: "officialabemac",

  facebook: "",

  domain: "",

  generateQR: true,

  spotify: "https://open.spotify.com/artist/7sHO2trSS1fdIoI51NuUOt",

appleMusic: "https://music.apple.com/us/artist/abe-mac/664358633",

youtube: "https://www.youtube.com/channel/UCNMIsi1r_oGUFT4gx-8CUZw",

bookingEmail: "Stevemartin677@gmail.com",

  primaryColor: "#250F0B",

  secondaryColor: "#DD8D4C",

  features: [
  "Live Performances",
  "Original Music",
  "Streaming Platforms",
  "Available For Booking"
]

};

export default business;
