const location = {
  "type": "events",
  "events": [
    {
      "name": "Lantern Oaks Resort",
      "date": "07/11/26",
      "time": "6pm",
      "address": "3255 S State Hwy 16, Fredericksburg, TX 78624"
    },
    {
      "name": "Cadillac Cowboys",
      "date": "07/18/26",
      "time": "",
      "address": ""
    },
    {
      "name": "07/27/26",
      "date": "",
      "time": "",
      "address": ""
    }
  ]
};

export default location;
