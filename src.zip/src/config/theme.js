const theme = {

  primary: "#250F0B",

  secondary: "#DD8D4C",

  background: "#FFFFFF",

  text: "#DD8D4C"

};

export default theme;
