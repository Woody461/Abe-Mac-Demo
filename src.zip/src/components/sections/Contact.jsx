import business from "../../config/business";

import Section from "../ui/Section";
import SectionTitle from "../ui/SectionTitle";

function Contact() {

  const hasContactInfo =
    business.phone ||
    business.email ||
    business.address ||
    business.instagram ||
    business.facebook;

  // Nothing to show
  if (!hasContactInfo && !business.generateQR) {
    return null;
  }

  return (

    <Section id="contact">

      <div className="mx-auto max-w-6xl">


      </div>

    </Section>

  );

}

export default Contact;