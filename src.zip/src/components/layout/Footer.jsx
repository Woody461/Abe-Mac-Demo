import business from "../../config/business";

function Footer() {

  const hasContact =
    business.phone ||
    business.email ||
    business.address;

  return (
    <footer
      className="text-white"
      style={{
        backgroundColor: "var(--secondary)"
      }}
    >

      <div className="mx-auto max-w-7xl px-6 py-16">

        <div
          className={`grid gap-12 ${
            hasContact && business.generateQR
              ? "md:grid-cols-3"
              : "md:grid-cols-2"
          }`}
        >

          {/* Business */}

          <div>

            <img
              src="/images/logo.png"
              alt={business.name}
              className="mb-6 h-20 w-20 rounded-full border-2 object-cover"
              style={{
                borderColor: "var(--primary)"
              }}
            />

            <h2 className="text-2xl font-bold">
              {business.name}
            </h2>

            <p className="mt-4 text-gray-300">
              {business.tagline}
            </p>

          </div>


        </div>

        <div className="mt-12 border-t border-gray-600 pt-8 text-center text-gray-400">

          © {new Date().getFullYear()} {business.name}

        </div>

      </div>

    </footer>
  );
}

export default Footer;